from pyspark.sql import SparkSession

def run_job():
    # Initialize Spark Session
    # appName is standard for identifying the job in the Spark UI
    spark = SparkSession.builder \
        .appName("AirflowClientModeJob_2025") \
        .getOrCreate()

    print("Spark Session successfully started in Client Mode.")

    # Create simple data for testing
    data = [("Alice", 34), ("Bob", 45), ("Charlie", 29)]
    df = spark.createDataFrame(data, ["Name", "Age"])

    # Perform a simple transformation
    df_filtered = df.filter(df.Age > 30)
    
    print("Filtered Results:")
    df_filtered.show()

    # Success marker logic is common for pipeline monitoring
    print("Job completed successfully.")
    spark.stop()

if __name__ == "__main__":
    run_job()

from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

# Default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id="spark_client_mode_workflow_2025",
    default_args=default_args,
    description="A simple Spark submit DAG in client mode",
    schedule=None,  # Manual trigger
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=['spark', 'client_mode'],
) as dag:

    # task to run the Spark job
    submit_spark_job = SparkSubmitOperator(
        task_id="run_pyspark_client_task",
        application="/opt/spark_scripts/sample_script.py",
        # ESSENTIAL: 'client' mode runs the driver on the Airflow worker
        deploy_mode="client",
        # Ensure 'spark_default' is configured in Airflow UI -> Admin -> Connections
        conn_id="spark_default",
        # conf={
        #     "spark.master": "spark://spark-master:7077",
        #     "spark.pyspark.python": "python3"
        # },
        name="airflow_pyspark_job",
        verbose=True
    )
